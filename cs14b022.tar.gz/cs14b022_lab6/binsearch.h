#ifndef BINSEARCH_H
#define BINSEARCH_H
int Find(int *,int,int,int);
#endif
