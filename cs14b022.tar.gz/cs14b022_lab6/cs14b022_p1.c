#include <stdio.h>
#include <stdlib.h>
#include "binsearch.h"

int main(int argc,char* argv[])
{	
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	int k,i,n,j;
	fscanf(f1,"%d/n",&n);
	int a[n],*p[n];
	for(j=0;j<n;j++)
	{
		fscanf(f1,"%d/n",&k);
		p[j]=(int *)malloc(k*sizeof(int));
		for(i=0;i<k;i++)
		fscanf(f1,"%d ",p[j]+i);
		a[j]=*(p[j]+Find(p[j],0,k-1,k));
	}
	for(i=0;i<n;i++)
	fprintf(f2,"%d\n",a[i]);
	fclose(f1);
	fclose(f2);
}
