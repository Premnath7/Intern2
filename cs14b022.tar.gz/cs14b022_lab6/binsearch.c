#include <stdio.h>
#include <stdlib.h>
#include "binsearch.h"
int Find(int *arr,int left,int right,int k)
{	
	int mid = (left+right)/2;
	int p,i;
	if(mid==1)
	{
	if(*(arr+mid-1)>*(arr+mid))
	return 0;
	}
	if(mid==k-2)
	{
	if(*(arr+mid+1)>*(arr+mid))
	return k-1;	
	}
	if(*(arr+mid)>*(arr+mid+1) && *(arr+mid)>*(arr+mid-1))
	return mid;
	else if(*(arr+mid)>=*(arr+mid+1) && *(arr+mid)<*(arr+mid-1))
	return Find(arr,left,mid,k);
	else if(*(arr+mid)<*(arr+mid+1) && *(arr+mid)>=*(arr+mid-1))
	return Find(arr,mid,right,k);
	else if(*(arr+mid)==*(arr+mid+1) && *(arr+mid)>*(arr+mid-1))
	{
		p=0;
		for(i=mid;i<k;i++)
		{
			if(*(arr+mid)>=*(arr+i))
			p=1;
			else
			{
				p=0;
				break;
			}
		}
		if(p==1)
		return mid;
		else
		return Find(arr,mid,right,k);
	}
	else if(*(arr+mid)>*(arr+mid+1) && *(arr+mid)==*(arr+mid-1))
	{
		p=0;
		for(i=mid;i<=0;i++)
		{
			if(*(arr+mid)>=*(arr+i))
			p=1;
			else
			{
				p=0;
				break;
			}
		}
		if(p==1)
		return mid;
		else
		return Find(arr,left,mid,k);
	}
	else if(*(arr+mid)==*(arr+mid+1) && *(arr+mid)==*(arr+mid-1))
	{
		p=0;
		for(i=mid;i<k;i++)
		{
			if(*(arr+mid)>=*(arr+i))
			p=1;
			else
			{
				p=0;
				break;
			}
		}
		if(p==0)
		return Find(arr,mid,right,k); 
		p=0;
		for(i=mid;i<=0;i++)
		{
			if(*(arr+mid)>=*(arr+i))
			p=1;
			else
			{
				p=0;
				break;
			}
		}
		if(p==0)
		return Find(arr,left,mid,k);
		return mid;
	}
}
	
	

