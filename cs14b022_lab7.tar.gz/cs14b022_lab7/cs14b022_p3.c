#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	struct node* left;
	struct node* right;
};
int max(int a,int b,int c);
int maxheight(struct node *start);
void add(struct node **tree,int a[][2],int pn,char *p,int k);
int diameter(struct node *start);
struct node* create_tree(char *);
struct node* create_tree(char* filename)
{
	FILE *fp = fopen(filename,"r");
	int k,i,check,j;
	int pn;
	fscanf(fp,"%d",&k);
	int a[k][2];char p[k];
	for(i=0;i<k;i++)
	{
		fscanf(fp,"%d",&a[i][0]);
		fscanf(fp,"%d",&a[i][1]);
		fscanf(fp," %c",&p[i]);
	}
	for(i=0;i<k;i++)
	{
		pn=a[i][0];
		check=1;
		for(j=0;j<k;j++)
		{
		if(a[i][0]==a[j][1])
		{
		check=0;
		break;
		}
		}
		if(check==1)
		break;
	}
	struct node *start;
	start = NULL;
	add(&start,a,pn,p,k);
	return start;
	printf("%c",p[1]);
}

void add(struct node **tree,int a[][2],int pn,char *p,int k)
{
	int ch,i,j;char pos;
	if((*tree)==NULL)
					{
						struct node *temp;
						temp=(struct node *)malloc(sizeof(struct node));
						temp->left=NULL;
						temp->right=NULL;
						temp->data=pn;
						*tree = temp;
					}
	for(i=0;i<k;i++)
	{
		if(a[i][0]==pn)
		{
			         pos=p[i];					
						if(pos=='L')
						add(&((*tree)->left),a,a[i][1],p,k);
						if(pos=='R')
						add(&((*tree)->right),a,a[i][1],p,k);
			
		}
	}
}
int max(int a,int b,int c)
{
if((a>=b && a>c) || (a>b && a>=c))
return a;
else if((b>=a && b>c) || (b>a && b>=c))
return b;
else if((c>=a && c>b) || (c>a && c>=b))
return c;
else
return a;
}

int diameter(struct node *start)
{
if(start==NULL)
return 0;
else
return max(diameter(start->left),diameter(start->right),maxheight(start->left)+maxheight(start->right));
}

int maxheight(struct node *start)
{
if(start==NULL)
return 0;
else
return 1+((maxheight(start->left)>=maxheight(start->right))?maxheight(start->left):maxheight(start->right));
}
int main(int argc,char* argv[])
{
	struct node *a;
	a=create_tree(argv[1]);
	printf("%d",diameter(a));
	return 0;
} 
