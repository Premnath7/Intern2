#include <stdio.h>
#include <stdlib.h>
struct node
{
	int data;
	struct node* left;
	struct node* right;
};
void add(struct node **tree,int a[][2],int pn,char *p,int k);
struct node* create_tree(char *);
struct node* create_tree(char* filename)
{
	FILE *fp = fopen(filename,"r");
	int k,i,check,j;
	int pn;
	fscanf(fp,"%d",&k);
	int a[k][2];char p[k];
	for(i=0;i<k;i++)
	{
		fscanf(fp,"%d",&a[i][0]);
		fscanf(fp,"%d",&a[i][1]);
		fscanf(fp," %c",&p[i]);
	}
	for(i=0;i<k;i++)
	{
		pn=a[i][0];
		check=1;
		for(j=0;j<k;j++)
		{
		if(a[i][0]==a[j][1])
		{
		check=0;
		break;
		}
		}
		if(check==1)
		break;
	}
	struct node *start;
	start = NULL;
	add(&start,a,pn,p,k);
	return start;
	printf("%c",p[1]);
}

void add(struct node **tree,int a[][2],int pn,char *p,int k)
{
	int ch,i,j;char pos;
	if((*tree)==NULL)
					{
						struct node *temp;
						temp=(struct node *)malloc(sizeof(struct node));
						temp->left=NULL;
						temp->right=NULL;
						temp->data=pn;
						*tree = temp;
					}
	for(i=0;i<k;i++)
	{
		if(a[i][0]==pn)
		{
			         pos=p[i];					
						if(pos=='L')
						add(&((*tree)->left),a,a[i][1],p,k);
						if(pos=='R')
						add(&((*tree)->right),a,a[i][1],p,k);
			
		}
	}
}




