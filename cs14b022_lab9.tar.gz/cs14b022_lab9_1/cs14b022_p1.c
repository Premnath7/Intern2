#include <stdio.h>
int majority(int a[],int n);
int isequals(int n1,int n2);
int isequals(int n1,int n2)
{
if((n1%5)==(n2%5))
return 1;
else
return 0;
}
int majority(int a[],int n)
{
	int k,m1,m2,l1=0,l2=0,i;
	if(n==1)
	return a[0];
	k=n/2;
	m1=majority(a,k);
	m2=majority(a+k,n-k);
	if(isequals(m1,m2))
	return m1;
	for(i=0;i<n;i++)
	if(isequals(a[i],m1))
	l1++;
	for(i=0;i<n;i++)
	if(isequals(a[i],m2))
	l2++;
	if(l1>k)
	return m1;
	else if(l2>k)
	return m2;
	else
	return -1;
}
int main(int argc,char *argv[])
{
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	int n,i;
	fscanf(f1,"%d\n",&n);
	int a1[n];
	for(i=0;i<n-1;i++)
	fscanf(f1,"%d\n",&a1[i]);
	fscanf(f1,"%d",&a1[i]);
	int r=majority(a1,n);
	if(r==-1)
	fprintf(f2,"No majority element");
	else
	fprintf(f2,"%d",r);
	fclose(f1);
	fclose(f2);
}



