#include <stdio.h>

float median(int a1[],int a2[],int n)
{
	int m1,m2;
	if (n == 1)
        return (a1[0] + a2[0])/2.0;
	if(n==2)
	return ((a1[0]>a2[0]?a1[0]:a2[0]) + (a1[1]>a2[1]?a2[1]:a1[1])) / 2.0;
	if(n%2==0)
	{
	m1=(a1[n/2]+a1[n/2-1])/2;
	m2=(a2[n/2]+a2[n/2-1])/2;
	}
	else
	{
	m1=a1[n/2];
	m2=a2[n/2];
	}
	if(m1==m2)
	return m1;
	if(m1 < m2)
	{
		    if(n%2==0)
		    return median(a1+n/2-1,a2,n-n/2+1);
		    else
		    return median(a1+n/2,a2,n-n/2);
	}
	else
	{
		    if(n%2==0)
		    return median(a2+n/2-1,a1,n-n/2+1);
		    else
		    return median(a2+n/2,a1,n-n/2);
	}
}
int main(int argc,char *argv[])
{
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	int n,i;
	fscanf(f1,"%d",&n);
	int a1[n],a2[n];
	for(i=0;i<n-1;i++)
	fscanf(f1,"%d, ",&a1[i]);
	fscanf(f1,"%d",&a1[i]);
	for(i=0;i<n-1;i++)
	fscanf(f1,"%d, ",&a2[i]);
	fscanf(f1,"%d",&a2[i]);
	float r=median(a1,a2,n);
	fprintf(f2,"%f",r);
	fclose(f1);
	fclose(f2);
}




