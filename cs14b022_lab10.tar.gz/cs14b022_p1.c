#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int dict(char *p);
char* word(char *w,int s,int e);
int check(char* a,int m[],int k[],int n1,int i,int n2);
int dict(char *p)
{	
	int i;
	char a[24][20]={"this","is","good","question","cannot","be","broken","how","do","you","write","such","program","test","me","i","if","you","can","and","print","me","a","an"};
	for(i=0;i<24;i++)
	{
	if(strcmp(p,a[i])==0)
	{//printf("%s passed\n",p);
	return 1;}
	}
	return 0;
}
char* word(char *w,int s,int e)
{
	char *k;int i;
	k=(char *)malloc(sizeof(e-s+2));
	int n=e-s+2;
	for(i=0;i<n-1;i++)
	k[i]=w[s+i];
	k[n-1]='\0';
	return k;
}

int check(char* a,int m[],int k[],int n1,int i,int n2)
{
	char *p;int j;
	if(i==n2 && m[n2-1]==1)
	return 1;
	else if(i==n2 && m[n2-1]==0)
	return 0;
	m[i]=0;
	p=word(a,n2-n1,i);
	//printf("%s\n",p);
	if(dict(p))
	{
		m[i]=1;
		if(check(a,m,k,n2-i-1,i+1,n2))
		{k[i]=1;
		return 1;}
	}
	/*for(j=n2-n1;j<=i;j++)
	{
		if(m[j-1]==1)
		p=word(a,j,i);
		if(dict(p))
		{
			m[i]=1;
			if(check(a,m,k,n2-i-1,i+1,n2))
			{k[i]=1;
			return 1;}
		}
	}*/
	return check(a,m,k,n1,i+1,n2);
}
int main(int argc,char* argv[])
{
	char a[1000];int n,j;
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	int p;
	fscanf(f1,"%d",&p);
	for(j=0;j<p;j++)
	{
		fscanf(f1,"%s",a);
		n=strlen(a);int k[n],i;int m[n];
		for(i=0;i<n;i++)
		k[i]=0;
		if(check(a,m,k,n,0,n))
		{
		for(i=0;i<n;i++)
		{
			if(k[i]==1)
			fprintf(f2,"%c ",a[i]);
			else
			fprintf(f2,"%c",a[i]);
		}
		fprintf(f2,"\n");
		}
		else
		fprintf(f2,"Invalid String\n");
	}
}
