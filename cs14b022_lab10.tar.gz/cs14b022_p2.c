#include <stdio.h>

int check(int arr[],int n,int t,int k[],int *m)
{
	if(t==0)
	return 1;
	if(n==0 && t!=0)
	return 0;
	if(arr[n-1]>t)
	return check(arr,n-1,t,k,m);
	if(check(arr,n-1,t-arr[n-1],k,m))
		{
			k[*m]=arr[n-1];
			(*m)++;
			return 1;
		}
	else if(check(arr,n-1,t,k,m))
	return 1;	
	return 0;
}
int main(int argc,char *argv[])
{
int n,i,t,p,j;int a[100],k[100],m;
FILE *f1=fopen(argv[1],"r");
FILE *f2=fopen(argv[2],"w");
fscanf(f1,"%d",&p);
for(j=0;j<p;j++)
{	m=0;
	fscanf(f1,"%d",&n);
	for(i=0;i<n;i++)
	fscanf(f1,"%d",&a[i]);
	fscanf(f1,"%d",&t);
	for(i=0;i<n;i++)
	k[i]=0;
	if(check(a,n,t,k,&m))
	{
	for(i=0;i<m;i++)
	fprintf(f2,"%d ",k[i]);
	fprintf(f2,"\n");
	}
	else
	fprintf(f2,"No subset found\n");
}
}
