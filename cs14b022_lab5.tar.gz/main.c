#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "stack.h"
int main()
{
	struct SNode *startptr=NULL;
	Push(&startptr,'a');
	Push(&startptr,'b');
	Push(&startptr,'c');
	printf("%d\n",IsEmpty(startptr));
	printf("%c\n",Top(startptr));
	struct SNode *tempptr = startptr;
	while(tempptr!=NULL)
	{
	printf("%c\n",tempptr->data);
	tempptr=tempptr->next;
	}
	return 0;
}



