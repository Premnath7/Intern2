#ifndef STACK_H
#define STACK_H
struct SNode
{
char data;
struct SNode* next;
};

void Push(struct SNode** , char );
char Pop(struct SNode** );
bool IsEmpty(struct SNode* );
char Top(struct SNode* );
#endif
