#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int Equals(char *p1,char *p2)
{
	int n1 = strlen(p1);
	int n2 = strlen(p2);
	if(n1==n2)
	{
		if(n1%2==1)
		{
			if(strcmp(p1,p2)==0)
			return 1;
			else 
			return 0;
		}
		else if(n1%2==0)
		{
			int i;
			char *s11,*s12,*s21,*s22;
			s11=(char *)malloc(n1/2+1);
			s12=(char *)malloc(n1/2+1);
			s21=(char *)malloc(n2/2+1);
			s22=(char *)malloc(n2/2+1);
			for(i=0;i<n1/2;i++)
			*(s11+i)=*(p1+i);
			for(i=0;i<n1/2;i++)
			*(s12+i)=*(p1+i+(n1/2));
			for(i=0;i<n2/2;i++)
			*(s21+i)=*(p2+i);
			for(i=0;i<n2/2;i++)
			*(s22+i)=*(p2+i+(n2/2));
			*(s11+(n1/2))='\0';
			*(s12+(n1/2))='\0';
			*(s21+(n1/2))='\0';
			*(s22+(n1/2))='\0';
			if(Equals(s11,s21)==1 && Equals(s12,s22)==1)
			return 1;
			else if(Equals(s11,s22)==1 && Equals(s12,s21)==1)
			return 1;
			else 
			return 0;
			
			

		}
	}
	else
	return 0;
}
int main(int argc,char *argv[])
{	
	int k,i;
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	fscanf(f1,"%d",&k);
	char s1[100],s2[100];
	for(i=0;i<k;i++)
	{
	fscanf(f1,"%s %s",s1,s2);
	fprintf(f2,"%d\n",Equals(s1,s2));	
	}
}
