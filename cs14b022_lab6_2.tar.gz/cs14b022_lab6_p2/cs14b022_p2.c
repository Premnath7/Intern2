#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int check(char *s,char *a,char *b);
void part(char *a,char **k,int low,int high);
void merge(char *a,char **k,int low,int mid,int high);
int main(int argc,char *argv[])
{
	int k,i;
	FILE *f1=fopen(argv[1],"r");
	FILE *f2=fopen(argv[2],"w");
	char a[1000];
	fscanf(f1,"%s",a);
	fscanf(f1,"%d",&k);
	char *in[k];
	for(i=0;i<k;i++)
	{
	in[i]=(char *)malloc(1000);
	fscanf(f1,"%s",in[i]);
	}
	part(a,in,0,k-1);
	for(i=0;i<k;i++)
	fprintf(f2,"%s\n",in[i]);
	fclose(f1);
	fclose(f2);
	return 0;
}
int check(char *s,char *a,char *b)
{
	int i,j;int p1,p2;
	int len=strlen(s);
	for(j=0;*(a+j)!='\0' && *(b+j)!='\0';j++)
	{
		for(i=0;i<len;i++)
		{
			if(*(a+j)==*(s+i))
			p1=i;
			if(*(b+j)==*(s+i))
			p2=i;
		}
		if(p1!=p2)
		{
			return (p1-p2);
		}
	}
	if(*(a+j)=='\0' && *(b+j)=='\0')
	return 0;
	else if(*(a+j)=='\0')
	return -1;
	else
	return 1;
}

void part(char *a,char **k,int low,int high)
{
	int mid;
	if(low<high)
	{
		mid=(low+high)/2;
		part(a,k,low,mid);
		part(a,k,mid+1,high);
		merge(a,k,low,mid,high);
	}
}
void merge(char *a,char **k,int low,int mid,int high)
{
	char *temp[1000];int  p,m=mid+1,i=0,l=low;
	while((l<=mid)&&(m<=high))
	{
		if(check(a,*(k+l),*(k+m))<0)
		{
			temp[i]=(char *)malloc(1000);
			strcpy(temp[i],*(k+l));
			l++;
		}
		else
		{
			temp[i]=(char *)malloc(1000);
			strcpy(temp[i],*(k+m));
			m++;
		}
	i++;
	}
	if(l>mid)
	{
		for(p=m;p<=high;p++)
		{
			
			temp[i]=(char *)malloc(1000);
			strcpy(temp[i],*(k+p));
			i++;
		}
	}
	else
	{
		for(p=l;p<=mid;p++)
		{
			temp[i]=(char *)malloc(1000);
			strcpy(temp[i],*(k+p));
			i++;
		}
	}
	for(i=0,p=low;p<=high;p++)
	{
		*(k+p)=temp[i];
		i++;		
	}
}

